<!DOCTYPE html>
<html lang="en">

<head>
    <title>404</title>
    <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">

    <meta name="title" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="robots" content="">
    <meta charset="utf-8">

</head>

<body>
    <div id="error-404">
        page doesn't exist - return?
    </div>
</body>

</html>